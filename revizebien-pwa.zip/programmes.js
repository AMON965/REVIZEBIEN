/* RevizeBien - programmes par classe (leçons).
   Sources officielles : https://dpfc-ci.net (Direction de la Pédagogie et de la Formation Continue, MENA).
   Pour ajouter une classe : PROG["5e"]={"Maths":["Leçon 1","Leçon 2"],...}  (les noms de matières doivent exister dans SUBJECTS). */
const SUBJECTS={
"6e":["Français","Maths","Anglais","Hist-Géo","SVT"],
"5e":["Français","Maths","Anglais","Hist-Géo","SVT","Physique-Chimie"],
"4e":["Français","Maths","Anglais","Hist-Géo","SVT","Physique-Chimie"],
"3e":["Français","Maths","Anglais","Hist-Géo","SVT","Physique-Chimie"],
"2nde A":["Français","Anglais","Hist-Géo","Maths","SVT","Physique-Chimie"],
"2nde C":["Maths","Physique-Chimie","SVT","Français","Anglais","Hist-Géo"],
"1re A":["Français","Philosophie","Anglais","Hist-Géo","Maths","SVT"],
"1re C":["Maths","Physique-Chimie","SVT","Français","Philosophie","Anglais","Hist-Géo"],
"1re D":["Maths","Physique-Chimie","SVT","Français","Philosophie","Anglais","Hist-Géo"],
"Tle A":["Philosophie","Français","Hist-Géo","Anglais","Maths","SVT"],
"Tle C":["Maths","Physique-Chimie","SVT","Français","Philosophie","Anglais","Hist-Géo"],
"Tle D":["Maths","Physique-Chimie","SVT","Français","Philosophie","Anglais","Hist-Géo"]};
const PROG={
"6e":{"Français":["Le dialogue oral","Œuvre intégrale","Textes autonomes : la lettre personnelle","Textes autonomes : le texte narratif","Textes autonomes : le texte descriptif","Expression écrite : la lettre personnelle","Expression écrite : le récit","Expression écrite : la description","Grammaire : la phrase","Grammaire : le groupe nominal","Grammaire : le discours direct et indirect","Grammaire : le verbe","Grammaire : le groupe verbal","Grammaire : les adverbes","Orthographe lexicale","Orthographe grammaticale"]},
"Tle D":{
"Maths":["Nombres complexes","Limites et continuité","Dérivabilité et étude de fonctions","Primitives","Fonctions logarithmes","Fonctions exponentielles et puissances","Calcul intégral","Suites numériques","Équations différentielles","Statistiques à deux variables","Probabilité conditionnelle et variable aléatoire","Nombres complexes et géométrie du plan"],
"Physique-Chimie":["Cinématique du point","Mouvement du centre d’inertie d’un solide","Mouvements dans les champs uniformes","Oscillations mécaniques libres","Champ magnétique","Particule chargée dans un champ magnétique","Loi de Laplace","Auto-induction","Montages dérivateur et intégrateur","Oscillations électriques libres (LC)","Circuit RLC série sinusoïdal forcé","Résonance d’intensité","Puissance en régime sinusoïdal","Réactions nucléaires spontanées","Réactions nucléaires provoquées","Les alcools","Aldéhydes et cétones","Les amines","Acides carboxyliques et dérivés","Fabrication du savon","Les acides α-aminés","Solutions aqueuses et pH","Acide fort, base forte","Acide faible, base faible","Couples acide/base et classification","Réactions acido-basiques et solutions tampons","Dosage acido-basique"],
"SVT":["Le réflexe conditionnel","Le fonctionnement du tissu nerveux","Le fonctionnement du muscle strié squelettique","Le fonctionnement du cœur","Le devenir des cellules sexuelles chez les mammifères","Le fonctionnement des organes sexuels chez l’Homme","La reproduction chez les spermaphytes","La transmission d’un caractère héréditaire chez l’Homme","La transmission de deux caractères héréditaires","Le maintien de la constance du milieu intérieur","Le système de défense de l’organisme","L’infection de l’organisme par le VIH","La mise en place des gisements miniers en Côte d’Ivoire","L’exploitation des gisements miniers en Côte d’Ivoire","L’amélioration et la protection des sols"],
"Philosophie":["La dissertation philosophique","Le commentaire de texte philosophique","La connaissance de l’homme","La vie en société","Dieu et la religion","La valeur de la philosophie","Le progrès et le bonheur","Langage et vérité","La connaissance scientifique"],
"Français":["Œuvre intégrale narrative (roman)","Groupement de textes théâtraux","Résumé du texte argumentatif","Le commentaire composé","La dissertation littéraire","Préparation à l’oral du baccalauréat"],
"Anglais":["Lifestyle: moving with the times","Freedom and civil rights","Development issues","What the future holds","Managing resources","Contemporary Africa","International issues","Cultural differences","Justice","Demography"],
"Hist-Géo":["L’ONU","L’ère de la bipolarisation (1947-1991)","De la fin de la guerre froide à un monde multipolaire","La montée des nationalismes en Afrique","L’accession de la Côte d’Ivoire à l’indépendance","L’accession de l’Algérie à l’indépendance","L’Union Africaine","Croyances et valeurs dans le monde occidental","Mutations de la civilisation négro-africaine","Géo : fondements de l’économie ivoirienne","Géo : secteurs d’activités de la Côte d’Ivoire","Géo : problèmes de développement de la Côte d’Ivoire","Géo : fondements de l’économie de la France","Géo : la France, économie dominée par le tertiaire","Géo : la CEDEAO","Géo : relations UE/ACP"],
}};
